﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;
using System.IO;

public partial class Admin_BasicCourses : System.Web.UI.Page
{
    static int a = 0;
   static int id;
     protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            binding1();
        }
    }
  

    protected void sub_button_Click(object sender, EventArgs e)
    {
        if (validateData() == 0)
        {
            
            lb_msg.Text = "";
            
            if (a == 0)
            {
                
                string str = "insert into course(course) values('" + tb_name.Text + "')";
                int var = Database.Execute(str);

                if (var == 1)
                {
                    lb_msg.ForeColor = System.Drawing.Color.Green;
                    lb_msg.Text = "Record Inserted Successfully.";
                    data();
                }
                else
                {
                    lb_msg.ForeColor = System.Drawing.Color.Red;
                    lb_msg.Text = "Error in Record Entry.";
                }
            }
            else
            {
               

                        string query1 = "update course set course='" + tb_name.Text + "' where id=" + id + "";
                        int res = Database.Execute(query1);
                        if (res == 1)
                        {
                            lb_msg.ForeColor = System.Drawing.Color.Green;
                            lb_msg.Text = "Record Updated Successfully.";
                            data();
                            
                        }
                        else
                        {
                            lb_msg.ForeColor = System.Drawing.Color.Red;
                            lb_msg.Text = "Error in Updating Record.";
                        }
                    
                a = 0;
            }
        }
        else
        {
            lb_msg.ForeColor = System.Drawing.Color.Red;
            lb_msg.Text = "fill up blank feilds.";
        }
        binding1(); 
    }
   
    void binding1()
    {
        string str = "select * from course order by id desc";
        DataSet ds = Database.get_simpleDataSet(str);
        gv_course.DataSource = ds.Tables[0];
        gv_course.DataBind();
        
    }

    protected void gv_course_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)gv_course.Rows[e.RowIndex];
        Label ll = (Label)gr.Cells[0].FindControl("lbl_id");

        string str1 = "delete from course where id =" + ll.Text + "";
        int res = Database.Execute(str1);

        if (res == 1)
        {
            lb_msg.ForeColor = System.Drawing.Color.Green;
            lb_msg.Text = "Record Deleted Successfully";
        }
        else
        {
            lb_msg.ForeColor = System.Drawing.Color.Red;
            lb_msg.Text = "Error For Deleting Record.";
        }

        binding1();
    }
    protected void gv_course_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_course.PageIndex = e.NewPageIndex;
       
        binding1();
    }
    protected void gv_course_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridViewRow gr = (GridViewRow)gv_course.Rows[e.NewEditIndex];
        a = 1;
        id = int.Parse(((Label)gr.Cells[0].FindControl("lbl_id")).Text.ToString());
        tb_name.Text =((Label)gr.Cells[0].FindControl("lbl_name")).Text;
       
        lb_msg.Text = "";
    }

    int validateData()
    {
        Panel Panel1 = (Panel)Page.FindControl("Panel1");
        int val = 0;
        foreach (Control c in Panel1.Controls)
        {
            if (c is TextBox)
            {
                (c as TextBox).CssClass = "tb10";
            }
        }

        foreach (Control c in Panel1.Controls)
        {
            if (c is TextBox)
            {
                if ((c as TextBox).Text.Trim() == "")
                {
                    (c as TextBox).CssClass = "texterror tb10";
                    val = 1;
                }
            }
        }


        return val;
    }
    int data()
    {
        Panel Panel1 = (Panel)Page.FindControl("Panel1");
        int s = 0;
        foreach (Control c in Panel1.Controls)
        {
            if (c is TextBox)
            {
                (c as TextBox).Text = "";
                s = 1;
            }
        }
        return s;
    }
}
