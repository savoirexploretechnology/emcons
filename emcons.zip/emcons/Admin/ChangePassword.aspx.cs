﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;

public partial class Admin_ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        string query = "";
        int res = 0;
        try
        {
             query = "select Password from Login where userID='" + Users.ActiveUser.UserID + "' and Role='"+Users.ActiveUser.Role+"'";
             DataSet ds = Database.get_simpleDataSet(query);
             if (ds.Tables[0].Rows[0][0].ToString().Equals(txt_old_pass.Text))
             {
                 if (txt_new_pass.Text.Equals(txt_confirm_pass.Text.ToString()))
                 {
                     query = "Update [Login] set [Password]='" + txt_new_pass.Text + "' where [UserID]='" + Users.ActiveUser.UserID + "' and [Role]='" + Users.ActiveUser.Role + "'"; 
                     res = Database.Execute(query);
                     if (res == 1)
                     {
                         lbl_msg.ForeColor = System.Drawing.Color.Green;
                         lbl_msg.Text = "Password changed successfully ";
                     }
                     else
                     {
                         lbl_msg.ForeColor = System.Drawing.Color.Red;
                         lbl_msg.Text = "Server Error, please try later.";
                     }
                 }
                 else
                 {
                     lbl_msg.ForeColor = System.Drawing.Color.Red;
                     lbl_msg.Text = "password not match.";
                 }
             }
             else
             {
                 lbl_msg.ForeColor = System.Drawing.Color.Red;
                 lbl_msg.Text = "old password is Incorrect.";
             }
        }
        catch (Exception ex)
        {

        }
    }
}
