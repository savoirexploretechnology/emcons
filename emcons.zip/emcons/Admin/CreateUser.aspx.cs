﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;

public partial class Admin_CreateUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        lb_error.Text = "";
        if (validateData() == 0)
        {
            if (validate() == null)
            {
                if (emailvalidate() == null)
                {
                    string query = "insert into login([UserID],[Password],[UserName],[Email],[Role],[Status]) values('" + txt_username.Text + "','" + txt_pswd.Text + "','" + txt_name.Text + "','" + txt_email.Text + "','" + dl_role.Text + "','1')";
                    int var = Database.Execute(query);
                    if (var == 1)
                    {
                        lb_error.Visible = true;
                        lb_error.ForeColor = System.Drawing.Color.Green;
                        lb_error.Text = "New User Created successfully";
                        data();

                    }
                    else
                    {
                        lb_error.Visible = true;
                        lb_error.ForeColor = System.Drawing.Color.Red;
                        lb_error.Text = "Error";
                    }
                }
                else
                {
                    lb_error.Visible = true;
                    lb_error.ForeColor = System.Drawing.Color.Red;
                    lb_error.Text = "email id is allready exist,try different";
                }
            }
            else
            {
                lb_error.Visible = true;
                lb_error.ForeColor = System.Drawing.Color.Red;
                lb_error.Text = "user is allready exist,try different";
            }
        }
    }

    public string validate()
    {
        string str = "";
        try
        {
            string query = "select username from login where userid='" + txt_username.Text + "'";
            DataSet ds;
            ds = Database.get_simpleDataSet(query);
            if (ds.Tables[0].Rows.Count > 0)
            {
                str = ds.Tables[0].Rows[0]["username"].ToString();
            }
            else
            {
                str = null;
            }
        }
        catch (Exception ex)
        {

        }
        return str;
    }

    public string emailvalidate()
    {
        string str = "";
        try
        {
            string query = "select username from login where email='" + txt_email.Text + "'";
            DataSet ds;
            ds = Database.get_simpleDataSet(query);
            if (ds.Tables[0].Rows.Count > 0)
            {
                str = ds.Tables[0].Rows[0]["username"].ToString();
            }
            else
            {
                str = null;
            }
        }
        catch (Exception ex)
        {

        }
        return str;
    }

    int validateData()
    {
        int val = 0;
        foreach (Control c in Panel1.Controls)
        {
            if (c is TextBox)
            {
                (c as TextBox).CssClass = "tb10";
            }
        }

        foreach (Control c in Panel1.Controls)
        {
            if (c is TextBox)
            {
                if ((c as TextBox).Text.Trim() == "")
                {
                    (c as TextBox).CssClass = "texterror tb10";
                    val = 1;
                }
            }
        }


        return val;
    }
    int data()
    {
        int s = 0;
        foreach (Control c in Panel1.Controls)
        {
            if (c is TextBox)
            {
                (c as TextBox).Text = "";
                s = 1;
            }
        }
        return s; 
    }
}
