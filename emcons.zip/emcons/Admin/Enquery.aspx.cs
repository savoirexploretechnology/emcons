﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;
using System.Text.RegularExpressions;

public partial class Admin_Enquery : System.Web.UI.Page
{
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            binding1();
        }

    }
    void binding1()
    {
        string str = "select * from Enquery order by id desc";
        DataSet ds = Database.get_simpleDataSet(str);
        gv_course.DataSource = ds.Tables[0];
        gv_course.DataBind();

    }

    protected void gv_course_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow gr = (GridViewRow)gv_course.Rows[e.RowIndex];
        Label ll = (Label)gr.Cells[0].FindControl("lbl_id");

        string str1 = "delete from Enquery where id =" + ll.Text + "";
        int res = Database.Execute(str1);

        if (res == 1)
        {
            lblmsg.ForeColor = System.Drawing.Color.Green;
            lblmsg.Text = "Record Deleted Successfully";
        }
        else
        {
            lblmsg.ForeColor = System.Drawing.Color.Red;
            lblmsg.Text = "Error For Deleting Record.";
        }

        binding1();
    }
    protected void gv_course_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_course.PageIndex = e.NewPageIndex;

        binding1();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

      if (isdate(TextBox2.Text) && isdate(TextBox1.Text))
        {
            lblmsg.Text = "";
            string str = "select * from Enquery where dateofsubmit>=#" + TextBox1.Text + "# and dateofsubmit<=#" + TextBox2.Text + "#";
            DataSet ds = Database.get_simpleDataSet(str);
            gv_course.DataSource = ds.Tables[0];
            gv_course.DataBind();
        }
        else
        {
            lblmsg.Text = "Date not in a currect Formate(MM/DD/YYYY)";
        }
    }

    public static bool isdate(string inputEmail)
    {
        
        string strRegex = @"^(0[1-9]|[12][0-9]|3[01])[-/.](0[1-9]|1[012])[-/.](19|20)\d\d$";
        Regex re = new Regex(strRegex);
        
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }


}
