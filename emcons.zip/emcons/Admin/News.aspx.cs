﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;

public partial class Admin_News : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["n_id"] != null)
            {
                string query = "select * from newsevent where id=" + int.Parse(Request.QueryString["n_id"].ToString()) + "";
                DataSet ds = Database.get_simpleDataSet(query);
                DataRow dr = ds.Tables[0].Rows[0];

                txttitle.Text = dr["title"].ToString();
                txtnews.Text = dr["news"].ToString();

            }
        }
    }
    protected void btn_Save_Click(object sender, EventArgs e)
    {
        if (txtnews.Text != "" && txttitle.Text!= "")
        {
            if (Request.QueryString["n_id"] == null)
            {
                string sql = "insert into newsevent(title,news,ndate) values('" + txttitle.Text + "','" + txtnews.Text + "','" + DateTime.Now.ToShortDateString() + "')";
                int res = Database.Execute(sql);

                if (res > 0)
                {
                    lb_error.Text = "Your Data Submited.";
                    lb_error.ForeColor = System.Drawing.Color.Green;
                    txtnews.Text = "";
                    txttitle.Text = "";
                }
                else
                {
                    lb_error.Text = "Error occured on Submition.";
                    lb_error.ForeColor = System.Drawing.Color.Green;
                }
            }
            else
            {
               string query = "update newsevent set title='" + txttitle.Text + "',news='" + txtnews.Text + "',ndate='" + DateTime.Now.ToShortDateString() + "' where id=" + int.Parse(Request.QueryString["n_id"].ToString()) + "";                
                int res = Database.Execute(query);
                if (res == 1)
                {
                    Response.Redirect("viewNews.aspx?msg=1");
                }
                else
                {
                    Response.Redirect("viewNews.aspx?msg=0");
                }
            }
        }
    }
}
