﻿// -- CUSTOM FUNCTIONS AND EFFECTS --

// -- NO CONFLICT MODE --
var $ = jQuery.noConflict();



// -- DOCUMENT.READY --
$(document).ready(function(){

$('.notification, .antispam').click(function () {
            $(this).fadeOut(800);
        });

        $('.tooltip-top').tipsy({ fade: false, gravity: 's' });
        $('.tooltip-right').tipsy({ fade: false, gravity: 'w' });
        $('.tooltip-bottom').tipsy({ fade: false, gravity: 'n' });
        $('.tooltip-left').tipsy({ fade: false, gravity: 'e' });
        
	
}); // END DOCUMENT.READY

//$(window).load( function() {

//	// -- CYCLE SLIDER INIT --

//	$('.cycle_slider').cycle({
//		fx:     'fade',
//		speed:  400,
//		timeout: 4000,
//		next: '.next',
//		prev: '.prev',
//		sync: 1,
//		pause: 1,
//		cleartype: true,
//		pager:  '.cycle_nav',
//		pagerAnchorBuilder: function(idx, slide) {
//			return '<li><a href="#"></a></li>';
//		}
//	});

//	$('.show_desc').fadeIn();
//});


function dmValidateField(elm)
{	
	if (elm.hasClass('frm_required'))
	{
		if (elm.val() == '')
		{
			elm.addClass('frm_error');
			return false; // error
		}
		else
		{
			elm.removeClass('frm_error');
			return true; // no error
		}
	}
	return true; // no error
}

function dmValidateForm(frm)
{	
	var frmElements = frm.find('input,textarea');
	
	frmElements.each(function() {
		$(this).bind('blur', function() {
			var elm = $(this);
			dmValidateField(elm);
		});
	});

	var wait = false;

	frm.bind('submit', function() {
		var error = false;

		if (wait == true)
			return false;

		wait = true;
		
		frmElements.each(function() {
			var elm = $(this);
			if (!dmValidateField(elm))
				error = true;
		});

		wait = false;
		
		if (error == false)
			return true
		else
			return false;
	});
}
function switch_style(css_title)
{
  var i, link_tag ;
  for (i = 0, link_tag = document.getElementsByTagName("link"); i < link_tag.length; ++i)
  {
    if ((link_tag[i].rel.indexOf("stylesheet") != -1) && link_tag[i].title == "main")
    {
      link_tag[i].href = "css/" + css_title + ".css";
    }
  }
}






