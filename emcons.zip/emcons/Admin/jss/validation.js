﻿$.fn.isSelectddlDL=function(){
    $(this).tipsy('hide');
    $(this).removeClass('errors');
    var isture = false;
    var value = $('#'+$(this).attr('id') +' option:selected').text();
   
    if ((!value || value.length == 0 || value == "==== Select ===="))
    {   $(this).tipsy('show', {fade: true, gravity: 'w error'});
         $(this).addClass('errors');
        isture = true;
    }
    return isture;
  

}
$.fn.checkEquality=function(id){
    var isture = false;
    var value = $(this).val();
    var to = $('#'+to).val();
    if(!(value == to))
    {
       isture = true
    }
    return isture;
}
$.fn.validateName=function(){
    
    $(this).tipsy('hide');
    $(this).removeClass('errors');
    var isture = false;
    var value = $(this).val();
    var expression = /^[a-z]([0-9a-z_ ])+$/i;
    if(!(expression.test(value)) || value == "Name" || value == "Message")  
    {
       $(this).tipsy('show', {fade: true, gravity: 'w error'});
       $(this).addClass('errors');
       isture = true
    }
    
    return isture;
}
$.fn.checkEmpty=function(){
   $(this).tipsy('hide');
    $(this).removeClass('errors');
   var isture = false;
   var value = $(this).val();
   if ((!value || value.length == 0))
    {
     $(this).tipsy('show', {fade: true, gravity: 'w error'});
        $(this).addClass('errors');
        isture = true;
    }
    return isture;
}
$.fn.validateMobile=function(){
   $(this).tipsy('hide');
    $(this).removeClass('errors');
    var isture = false;
    var value = $(this).val();
    var expression = /^[789][0-9]{9}$/;
    if(!(expression.test(value)))
    {
        $(this).tipsy('show', {fade: true, gravity: 'w error'});
        $(this).addClass('errors');
        isture = true;
    }
    return isture;
}

$.fn.validateDate = function() {
    $(this).tipsy('hide');
    $(this).removeClass('errors');
    var isture = false;
    var value = $(this).val();
    var expression = /^0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d/;
    if (!(expression.test(value))) {
        $(this).tipsy('show', { fade: true, gravity: 'w error' });
        $(this).addClass('errors');
        isture = true;
    }
    return isture;
}

$.fn.validateEmail=function(){
    $(this).tipsy('hide');
    $(this).removeClass('errors');
    var isture = false;
    var value = $(this).val();
    var expression = /^\w+([-.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
    if(!(expression.test(value)))
    {
        
        $(this).tipsy('show', {fade: true, gravity: 'w error'});
       $(this).addClass('errors');
       isture = true;
    }
    return isture;
}
$.fn.validateCustomUrl=function(){
    var isture = false;
    var value = $(this).val();
    var expression  = /[^a-zA-Z0-9-\s.]+/;

    if(!(expression.test(value)))
    {
       isture = true;
    }
    return isture;
}
$.fn.validateZip = function () {
    $(this).tipsy('hide');
    $(this).removeClass('errors');
    var isture = false;
    var value = $(this).val();
    var expression = /[0-9]/;
    if (!(expression.test(value))) {
        $(this).tipsy('show', { fade: true, gravity: 'w error' });
        $(this).addClass('errors');
        isture = true;
    }
    return isture;
}
$.fn.vlidateCheckBox = function () {
    var isture = false;
    if (!($(this).is(':checked'))){
        
        isture = true;
    }
    return isture;
}