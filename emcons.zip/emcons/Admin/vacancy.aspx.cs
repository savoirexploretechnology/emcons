﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;

public partial class Admin_vacancy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["n_id"] != null)
            {
                string query = "select * from vacancy where id=" + int.Parse(Request.QueryString["n_id"].ToString()) + "";
                DataSet ds = Database.get_simpleDataSet(query);
                DataRow dr = ds.Tables[0].Rows[0];

                txtCate.Text = dr["JobCategory"].ToString();
                txtcode.Text = dr["JobCode"].ToString();
                txtdepart.Text = dr["DepartMent"].ToString();
                txtloc.Text = dr["Location"].ToString();
                txtdate.Text = dr["JobExpiryDate"].ToString();
                txtquli.Text = dr["Qualification"].ToString();
                txtExperi.Text = dr["Experience"].ToString();

            }
        }
    }
    protected void btn_Save_Click(object sender, EventArgs e)
    {
        if (txtCate.Text != "" && txtcode.Text != "" && txtdepart.Text != "" && txtloc.Text != "" && txtdate.Text != "" && txtquli.Text != "" && txtExperi.Text != "" )
        {
            if (Request.QueryString["n_id"] == null)
            {
                string sql = "insert into vacancy(JobCategory,JobCode,DepartMent,Location,JobExpiryDate,Qualification,Experience) values('" + txtCate.Text + "','" + txtcode.Text + "','" +txtdepart.Text + "','"+txtloc.Text+"','"+txtdate.Text+"','"+txtquli.Text+"','"+txtExperi.Text+"')";
                int res = Database.Execute(sql);

                if (res > 0)
                {
                    lb_error.Text = "Your Data Submited.";
                    lb_error.ForeColor = System.Drawing.Color.Green;
                    txtCate.Text = "";
                    txtcode.Text = "";
                    txtdepart.Text = "";
                    txtloc.Text = "";
                    txtdate.Text = "";
                    txtquli.Text = "";
                    txtExperi.Text = "";
                }
                else
                {
                    lb_error.Text = "Error occured on Submition.";
                    lb_error.ForeColor = System.Drawing.Color.Green;
                }
            }
            else
            {
                string query = "update vacancy set JobCategory='"+txtCate.Text+"',JobCode='"+txtcode.Text+"',DepartMent='"+txtdepart.Text+"',Location='"+txtloc.Text+"',JobExpiryDate='"+txtdate.Text+"',Qualification='"+txtquli.Text+"',Experience='" + txtExperi.Text + "' where id=" + int.Parse(Request.QueryString["n_id"].ToString()) + "";
                int res = Database.Execute(query);
                if (res == 1)
                {
                    Response.Redirect("viewVacancy.aspx?msg=1");
                }
                else
                {
                    Response.Redirect("viewVacancy.aspx?msg=0");
                }
            }
        }
    }
}
