﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;

public partial class Admin_viewNews : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["msg"] != null)
            {
                if (Request.QueryString["msg"].ToString() == "1")
                {
                    lbl_msg.ForeColor = System.Drawing.Color.Green;
                    lbl_msg.Text = "Record has been successfully updated";
                }
                else
                {
                    lbl_msg.ForeColor = System.Drawing.Color.Red;
                    lbl_msg.Text = "Server Error, Record has not been modified";
                }
            }
            bindNotice();
        }
    }
    void bindNotice()
    {
        try
        {

            string query = "select * from NewsEvent";
            DataSet ds = Database.get_simpleDataSet(query);
            gv_editNotice.DataSource = ds.Tables[0];
            gv_editNotice.DataBind();
        }
        catch (Exception ex)
        {

        }
    }
    protected void gv_editNotice_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            GridViewRow gr = (GridViewRow)gv_editNotice.Rows[e.NewEditIndex];
            Label lbl_id = (Label)gr.Cells[2].FindControl("lbl_id");
            Response.Redirect("News.aspx?n_id=" + lbl_id.Text);
        }
        catch (Exception ex)
        {

        }
    }
    protected void gv_editNotice_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            GridViewRow gr = (GridViewRow)gv_editNotice.Rows[e.RowIndex];
            Label lbl_id = (Label)gr.Cells[2].FindControl("lbl_id");
            string query = "Delete from NewsEvent where ID=" + lbl_id.Text + "";
            Database.Execute(query);
            bindNotice();
        }
        catch (Exception ex)
        {

        }
    }
    protected void gv_editNotice_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_editNotice.PageIndex = e.NewPageIndex;
        bindNotice();
    }
}
