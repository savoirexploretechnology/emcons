﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


public partial class Admin_viewuser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string query = "select * from Login order by id desc";
        DataSet ds = SIVOR.Database.get_simpleDataSet(query);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gv_user.DataSource = ds.Tables[0];
            gv_user.DataBind();
        }
        else
        {
            lbl_msg.Text="No record";
            lbl_msg.ForeColor = System.Drawing.Color.Red;
        }
    }
    protected void gv_user_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_user.PageIndex = e.NewPageIndex;
        gv_user.DataBind();
    }
}
