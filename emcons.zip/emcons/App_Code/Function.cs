﻿using System;
using System.Data;
using System.Configuration;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Net.Mail;
using System.Net;

/// <summary>
/// Summary description for Function
/// </summary>
public class Function
{
	public Function()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private static string article = "Articles";
    public static string articles
    {
        get
        {
            return article;
        }
        set
        {
            article = value;
        }
    }    

    public static bool SendEmail(string emailto, string emailfrom, string subject, string body, string file)
    {
        try
        {
            MailMessage mail = new MailMessage();
            mail.Headers.Add("Reply-To", emailfrom);
            mail.From = new MailAddress(emailfrom);
            mail.To.Add(new MailAddress(emailto));
            mail.Subject = subject;
            mail.Body = body;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            if (file != "")
            {
                string filename = HttpContext.Current.Server.MapPath(file);
                Attachment attachfile = new Attachment(filename);
                mail.Attachments.Add(attachfile);
            }
            SmtpClient client = new SmtpClient();
            NetworkCredential SMTPUserInfo = new NetworkCredential("dilipmahto.it@gmail.com", "dsetfirst");
            client.Credentials = SMTPUserInfo;
            client.Host = "smtp.gmail.com";
            client.Port = 587;
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Send(mail);
            return true;

        }
        catch (Exception ex)
        {
            return false;
        }
       
    }
}
