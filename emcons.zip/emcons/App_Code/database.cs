﻿using System;
using System.Data;
using System.Configuration;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using System.Data.OleDb;

/// <summary>
/// Summary description for database
/// </summary>
namespace SIVOR
{
    public class Database
    {
        public Database()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public static string path = System.Web.HttpContext.Current.Server.MapPath("~\\App_Data\\Emcos.mdb");
        //public static string ConnectionString
        //{
        //    get
        //    {
        //        try
        //        {
                   
        //          return ;
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new ApplicationException("Unable to get Database Connection string from Web Config File");
        //        }
        //    }
        //}
        public static DataTable get_DataTable(string query)
        {
            try
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path);
                con.Open();
                OleDbDataAdapter da = new OleDbDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error occoured while retriving data from database");
            }
        }

        public static int Execute(string query)
        {
            try
            {
                //  string ret = "0";
                OleDbConnection con = new OleDbConnection();
                con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path;
                con.Open();
                OleDbCommand cmd = new OleDbCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return 1;
            }
            catch (Exception ex)
            {
                return 0;
                throw new ApplicationException("Error occoured while executing sql statement to database");
            }
        }
        public static DataSet get_DataSet(string query, string tablename, int curr, int size)
        {
            try
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path);
                con.Open();
                OleDbDataAdapter da = new OleDbDataAdapter(query, con);
                DataSet ds = new DataSet();
                da.Fill(ds, (curr - 1) * size, size, tablename);
                //dr.Close();
                con.Close();
                return ds;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error occoured while retriving data from database");
            }
        }

        public static DataSet get_simpleDataSet(string query)
        {
            try
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path);
                con.Open();
                OleDbDataAdapter da = new OleDbDataAdapter(query, con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                //       da.Fill(ds, (curr - 1) * size, size, tablename);
                //dr.Close();
                con.Close();
                return ds;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error occoured while retriving data from database");
            }
        }
    }

}
