﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;

public partial class Controls_header : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Buffer = true;
        Response.ExpiresAbsolute = DateTime.Now.AddDays(-1d);
        Response.Expires = -1500;
        Response.CacheControl = "no-cache";
        if (Session["ActiveUser"] == null)
        {
            FormsAuthentication.SignOut();
            FormsAuthentication.RedirectToLoginPage();
        }
        if (!IsPostBack)
        {
            string strRequestPage = Request.Url.Segments[Request.Url.Segments.Length - 2];

            try
            {
                if ((strRequestPage.Equals("Admin/")) && (Users.ActiveUser.Role == "Teaching Staff" || Users.ActiveUser.Role == "Non Teaching Staff" || Users.ActiveUser.Role == "Student"))
                {
                    Response.Redirect("~/Default.aspx");
                }
                else if ((strRequestPage.Equals("Student/")) && (Users.ActiveUser.Role == "Teaching Staff" || Users.ActiveUser.Role == "Non Teaching Staff" || Users.ActiveUser.Role == "Admin"))
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
            catch
            {
                Response.Redirect("../Login.aspx");
            }
           
        }
        lbl_user.Text = Users.ActiveUser.UserName;

    }
    protected void Page_Init(object sender, EventArgs e)
    {
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }

}
