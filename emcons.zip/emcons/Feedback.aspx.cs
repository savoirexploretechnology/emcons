﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SIVOR;
using System.IO;

public partial class Feedback : System.Web.UI.Page
{
    //protected void Page_Load(object sender, EventArgs e)
    //{
    //    if (!IsPostBack)
    //    {
    //        string sql = "select type from Type";
    //        DataTable dt = Database.get_DataTable(sql);

    //        DropDownList1.DataSource = dt;
    //        DropDownList1.DataTextField = "type";
    //        DropDownList1.DataValueField = "type";
    //        DropDownList1.DataBind();
    //    }
    //}
    bool thanks(string tomail, string frommail)
    {
        string path = Server.MapPath("autor.htm");
        StreamReader sr = new StreamReader(path);
        String Email_Body = sr.ReadToEnd();

        Email_Body = Email_Body.Replace("##name##", txtname.Text);
        Email_Body = Email_Body.Replace("##type##", DropDownList1.Text);
        Email_Body = Email_Body.Replace("##address##", txtAdd.Text);
        Email_Body = Email_Body.Replace("##contact##", txtCont.Text);
        Email_Body = Email_Body.Replace("##email##", txtemail.Text);
        Email_Body = Email_Body.Replace("##comment##", txtcomm.Text);
        bool res = Function.SendEmail(tomail, frommail, "Enquiry", Email_Body, "");
        if (res == true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    bool abc = thanks("emcons@emcons.co.in", txtemail.Text);
    //    if (abc == true)
    //    {
    //        Label1.Text = "Feedback send Successfully";
    //        Label1.ForeColor = System.Drawing.Color.Green;
    //    }
    //    else
    //    {
    //        Label1.Text = "Enquery not send Successfully";
    //        Label1.ForeColor = System.Drawing.Color.Red;
    //    }
    //}
}
